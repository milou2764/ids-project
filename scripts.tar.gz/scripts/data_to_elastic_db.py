from lxml import etree
from elasticsearch import Elasticsearch, helpers
import os
import glob
import pandas as pd
import re, string
from math import isnan

DATA_PATH = "/opt/data/TRAIN_ENSIBS/"


def claim_datasets(path):
    
    paths = glob.glob(os.path.join(path, "*"))
    
    for p in paths:
        yield p, pd.read_xml(p)

        

def main():

    #  init elasticsearch obj
    es = Elasticsearch([{'host': 'localhost',
                         'port': 9200,
                         'scheme': "http"}])

    #  claim dataset in pandas format
    for p, dataset in claim_datasets(DATA_PATH):
        ind = p[len(p) - p[::-1].find("/") : - 4]
        ind = re.sub(r'\W+', '', ind).lower()
        es.index(index=ind, body={'mappings':{'properties':{'protocolName':{'type':'keyword'}}}})
        for index, row in dataset.iterrows():
            document = row.to_dict()
            for key in document:
                value=document[key]
                if type(value)==float and isnan(document[key]):
                    document[key]="NULL"
            es.index(index=ind, body=document,id=index)

if __name__ == "__main__":
    main()

"""

BACKUP

"""

def etree_to_dict(t):
    d = {t.tag : map(etree_to_dict, t.iterchildren())}
    d.update(('@' + k, v) for k, v in t.attrib.iteritems())
    d['text'] = t.text
    return d


def get_big_dictionnary(i: int) -> dict:
    tree = etree.parse(datasets[i])
    root = tree.getroot()
    d = etree_to_dict(root)
    return d


