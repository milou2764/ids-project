"""

Load data from elastic database, and apply machine learning on it

"""

import pandas as pd

import os
import glob

from elasticsearch import Elasticsearch


HOST="localhost"
PATH="/opt/data/TRAIN_ENSIBS/"


def get_data(host):
    #  get database
    es = Elasticsearch([{'host': host, 'scheme' : 'http', 'port': 9200}])

    query = {
            "query": {
                "match": {
                    "database": "i"
                    }
                }
            }
    
    #  todo
    pass


def fake_get_data(path):
    for p in glob.glob(os.path.join(path, "*")):
        yield p, pd.read_xml(p)


def preprocess_data(data):
    print("columns : ", data.columns)
    
    #  put startDateTime and StopDateTime in a duration variable


    breakpoint()
    pass


def apply_ids(data):
    pass


def main():
    
    """
    df_data = get_data(HOST)
    """

    #  just for the moment
    for p, dataset in fake_get_data(PATH):
        print("file : ", p)
        df_data_preprocessed = preprocess_data(dataset)
    
        df_final = apply_ids(df_data_preprocessed)
        
        breakpoint()




if __name__ == "__main__":
    main()
